let name = "Audrey"
name.uppercased()

let uppercaseName = name.uppercased()
print("\(name)... \(name)... \(uppercaseName)! WAKE UP!")
// prints "Audrey... Audrey... AUDREY! WAKE UP!")
